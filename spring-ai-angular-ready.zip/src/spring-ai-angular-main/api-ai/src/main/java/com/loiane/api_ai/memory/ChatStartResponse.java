package com.loiane.api_ai.memory;

public record ChatStartResponse(String chatId, String message, String description) {
}
