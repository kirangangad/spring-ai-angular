package com.loiane.api_ai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiAiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiAiApplication.class, args);
	}

}
