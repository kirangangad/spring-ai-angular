package com.loiane.api_ai.booksprompt;

public record Book(String bookName, String isbn, String description) {
}
