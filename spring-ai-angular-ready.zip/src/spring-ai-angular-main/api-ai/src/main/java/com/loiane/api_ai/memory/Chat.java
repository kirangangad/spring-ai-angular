package com.loiane.api_ai.memory;

public record Chat(String id, String description) {
}
