package com.loiane.api_ai.chat;

public record ChatResponse(String message) {
}
