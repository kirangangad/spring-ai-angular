package com.loiane.api_ai.memory;

public record ChatMessage(String content, String type) {
}
