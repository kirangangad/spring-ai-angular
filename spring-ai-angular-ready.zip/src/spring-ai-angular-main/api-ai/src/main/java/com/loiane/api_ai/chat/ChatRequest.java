package com.loiane.api_ai.chat;

public record ChatRequest(String message) {
}