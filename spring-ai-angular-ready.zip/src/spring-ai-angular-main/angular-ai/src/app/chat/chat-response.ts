export interface ChatResponse {
  message: string;
  isBot: boolean;
}
