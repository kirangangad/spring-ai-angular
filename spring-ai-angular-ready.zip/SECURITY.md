# Security Policy

Report security vulnerabilities to the maintainer: Kiran Gangad (add email in README).
Do not include sensitive information in issues or PRs.
